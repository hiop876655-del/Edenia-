Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & WshShell.CurrentDirectory & "\IdeniaHisba.bat" & Chr(34), 0
Set WshShell = Nothing
