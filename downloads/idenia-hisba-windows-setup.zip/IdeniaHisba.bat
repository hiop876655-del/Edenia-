@echo off
chcp 65001 > nul
set "CURRENT_DIR=%~dp0"
set "APP_PATH=%CURRENT_DIR%app\index.html"

:: 1. Try Microsoft Edge in App Mode (Pre-installed on Windows 10/11)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%APP_PATH%" --window-size=1280,800 --window-position=100,50
    exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%APP_PATH%" --window-size=1280,800 --window-position=100,50
    exit /b 0
)

:: 2. Try Google Chrome in App Mode
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%APP_PATH%" --window-size=1280,800 --window-position=100,50
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%APP_PATH%" --window-size=1280,800 --window-position=100,50
    exit /b 0
)

:: 3. Fallback default browser
start "" "%APP_PATH%"
exit /b 0
