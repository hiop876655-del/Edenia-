var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var archiverModule = __toESM(require("archiver"), 1);
var ZipArchive2 = archiverModule.ZipArchive || archiverModule.default?.ZipArchive;
var app = (0, import_express.default)();
var PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
app.use(import_express.default.json());
app.get(["/health", "/api/health"], (req, res) => {
  res.json({ status: "ok", timestamp: Date.now() });
});
var DATA_DIR = import_path.default.join(process.cwd(), "server_data");
try {
  if (!import_fs.default.existsSync(DATA_DIR)) {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (e) {
  console.warn("Notice: server_data dir creation warning:", e);
}
var DB_FILE = import_path.default.join(DATA_DIR, "system_store.json");
function loadStore() {
  try {
    if (import_fs.default.existsSync(DB_FILE)) {
      const data = import_fs.default.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (parsed && Array.isArray(parsed.users)) {
        parsed.users = parsed.users.map((u) => ({
          ...u,
          subscriptionStatus: u.subscriptionStatus || (u.licenseExpiresAt && u.licenseExpiresAt > Date.now() ? "active" : "pending"),
          subscriptionDays: u.subscriptionDays || 30,
          subscriptionExpiresAt: u.subscriptionExpiresAt || u.licenseExpiresAt || 0
        }));
        return parsed;
      }
    }
  } catch (err) {
    console.error("Error reading store:", err);
  }
  const initialStore = {
    users: [],
    adminSecret: "Khaled2008"
  };
  saveStore(initialStore);
  return initialStore;
}
function saveStore(store) {
  try {
    import_fs.default.writeFileSync(DB_FILE, JSON.stringify(store, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving store:", err);
  }
}
var systemStore = loadStore();
app.get("/api/time", (req, res) => {
  const now = Date.now();
  res.json({
    success: true,
    serverTime: new Date(now).toISOString(),
    timestamp: now
  });
});
app.post("/api/register", (req, res) => {
  const { fullName, shopName, phone, password, tradeType, customTrade, deviceType, osDetails } = req.body;
  if (!fullName || !shopName || !phone || !password || !tradeType) {
    return res.status(400).json({
      success: false,
      message: "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0644 \u0645\u0637\u0644\u0648\u0628\u0629: \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u062B\u0644\u0627\u062B\u064A\u060C \u0627\u0633\u0645 \u0627\u0644\u0645\u062D\u0644\u060C \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641\u060C \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u060C \u0648\u0646\u0648\u0639 \u0627\u0644\u062A\u062C\u0627\u0631\u0629."
    });
  }
  const cleanPhone = phone.trim();
  const existing = systemStore.users.find((u) => u.phone === cleanPhone);
  if (existing) {
    return res.status(400).json({
      success: false,
      message: "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0645\u0633\u062C\u0644 \u0645\u0633\u0628\u0642\u0627\u064B\u060C \u064A\u0631\u062C\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0623\u0648 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0631\u0642\u0645 \u0622\u062E\u0631."
    });
  }
  const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "127.0.0.1";
  const newUser = {
    id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    fullName: fullName.trim(),
    shopName: shopName.trim(),
    phone: cleanPhone,
    password: String(password),
    tradeType,
    customTrade: customTrade || "",
    deviceType: deviceType || "Windows Desktop",
    osDetails: osDetails || (req.headers["user-agent"] || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"),
    ip: String(clientIp),
    registeredAt: (/* @__PURE__ */ new Date()).toISOString(),
    lastActive: (/* @__PURE__ */ new Date()).toISOString(),
    subscriptionStatus: "pending",
    subscriptionDays: 0,
    subscriptionExpiresAt: 0
  };
  systemStore.users.unshift(newUser);
  saveStore(systemStore);
  console.log(`[\u062A\u0633\u062C\u064A\u0644 \u062C\u062F\u064A\u062F] \u062A\u0627\u062C\u0631: ${fullName} (${shopName}) - \u0647\u0627\u062A\u0641: ${phone} - \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u0641\u0639\u064A\u0644`);
  res.json({
    success: true,
    message: "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062D\u0633\u0627\u0628 \u0628\u0646\u062C\u0627\u062D\u060C \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643 \u0645\u0646 \u0642\u0628\u0644 \u0627\u0644\u0625\u062F\u0627\u0631\u0629.",
    user: {
      id: newUser.id,
      fullName: newUser.fullName,
      shopName: newUser.shopName,
      phone: newUser.phone,
      tradeType: newUser.tradeType,
      customTrade: newUser.customTrade,
      deviceType: newUser.deviceType,
      subscriptionStatus: newUser.subscriptionStatus,
      subscriptionDays: newUser.subscriptionDays,
      subscriptionExpiresAt: newUser.subscriptionExpiresAt
    }
  });
});
app.post("/api/login", (req, res) => {
  const { phone, password } = req.body;
  if (!phone || !password) {
    return res.status(400).json({
      success: false,
      message: "\u064A\u0631\u062C\u0649 \u0625\u062F\u062E\u0627\u0644 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631."
    });
  }
  const cleanPhone = String(phone).trim();
  const cleanPass = String(password).trim();
  if (cleanPhone === "01121097822" && cleanPass === "Khaled2008") {
    console.log(`[\u062F\u062E\u0648\u0644 \u0627\u0644\u0645\u0627\u0644\u0643] \u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0648\u0627\u0633\u0637\u0629 \u0635\u0627\u062D\u0628 \u0627\u0644\u0645\u0646\u0635\u0629 (\u0627\u0644\u0645\u0647\u0646\u062F\u0633 \u062E\u0627\u0644\u062F)`);
    return res.json({
      success: true,
      message: "\u0645\u0631\u062D\u0628\u0627\u064B \u0628\u0643 \u064A\u0627 \u0645\u0647\u0646\u062F\u0633 \u062E\u0627\u0644\u062F - \u0645\u0627\u0644\u0643 \u0645\u0646\u0635\u0629 \u0627\u064A\u062F\u064A\u0646\u064A\u0627",
      isAdmin: true,
      user: {
        id: "admin_owner_khaled",
        fullName: "\u0627\u0644\u0645\u0647\u0646\u062F\u0633 \u062E\u0627\u0644\u062F (\u0645\u0627\u0644\u0643 \u0627\u0644\u0645\u0646\u0635\u0629)",
        shopName: "\u0625\u062F\u0627\u0631\u0629 \u0645\u0646\u0635\u0629 \u0627\u064A\u062F\u064A\u0646\u064A\u0627",
        phone: "01121097822",
        tradeType: "\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0646\u0638\u0627\u0645 \u0648\u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635",
        deviceType: "Windows / Android",
        role: "admin",
        isLoggedIn: true,
        subscriptionStatus: "active",
        subscriptionDays: 9999,
        subscriptionExpiresAt: Date.now() + 100 * 365 * 864e5
      }
    });
  }
  const user = systemStore.users.find((u) => u.phone === cleanPhone && u.password === cleanPass);
  if (!user) {
    return res.status(401).json({
      success: false,
      message: "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629."
    });
  }
  const now = Date.now();
  user.lastActive = (/* @__PURE__ */ new Date()).toISOString();
  if (user.subscriptionStatus === "active" && user.subscriptionExpiresAt > 0 && now >= user.subscriptionExpiresAt) {
    user.subscriptionStatus = "expired";
  }
  saveStore(systemStore);
  const remainingDays = user.subscriptionExpiresAt > now ? Math.ceil((user.subscriptionExpiresAt - now) / (1e3 * 60 * 60 * 24)) : 0;
  res.json({
    success: true,
    message: "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0646\u062C\u0627\u062D",
    isAdmin: false,
    user: {
      id: user.id,
      fullName: user.fullName,
      shopName: user.shopName,
      phone: user.phone,
      tradeType: user.tradeType,
      customTrade: user.customTrade,
      deviceType: user.deviceType,
      subscriptionStatus: user.subscriptionStatus,
      subscriptionDays: user.subscriptionDays,
      subscriptionExpiresAt: user.subscriptionExpiresAt,
      remainingDays,
      role: "merchant",
      isLoggedIn: true
    }
  });
});
app.post("/api/merchant/status", (req, res) => {
  const { phone } = req.body;
  if (!phone) {
    return res.status(400).json({ success: false, message: "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0645\u0637\u0644\u0648\u0628" });
  }
  const cleanPhone = String(phone).trim();
  if (cleanPhone === "01121097822") {
    return res.json({
      success: true,
      exists: true,
      status: "active",
      subscriptionExpiresAt: Date.now() + 100 * 365 * 864e5,
      remainingDays: 9999,
      serverTime: Date.now()
    });
  }
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.json({
      success: false,
      exists: false,
      status: "deleted",
      message: "\u062A\u0645 \u062D\u0630\u0641 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u0627\u062C\u0631 \u0645\u0646 \u0627\u0644\u0646\u0638\u0627\u0645\u060C \u062A\u0645 \u0642\u0641\u0644 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C."
    });
  }
  const now = Date.now();
  user.lastActive = (/* @__PURE__ */ new Date()).toISOString();
  if (user.subscriptionStatus === "active" && user.subscriptionExpiresAt > 0 && now >= user.subscriptionExpiresAt) {
    user.subscriptionStatus = "expired";
    saveStore(systemStore);
  }
  const remainingDays = user.subscriptionExpiresAt > now ? Math.ceil((user.subscriptionExpiresAt - now) / (1e3 * 60 * 60 * 24)) : 0;
  const remainingMs = Math.max(0, user.subscriptionExpiresAt - now);
  res.json({
    success: true,
    exists: true,
    status: user.subscriptionStatus,
    subscriptionDays: user.subscriptionDays,
    subscriptionExpiresAt: user.subscriptionExpiresAt,
    subscriptionActivatedAt: user.subscriptionActivatedAt,
    remainingDays,
    remainingMs,
    serverTime: now
  });
});
app.get("/api/admin/data", (req, res) => {
  const now = Date.now();
  let modified = false;
  systemStore.users.forEach((u) => {
    if (u.subscriptionStatus === "active" && u.subscriptionExpiresAt > 0 && now >= u.subscriptionExpiresAt) {
      u.subscriptionStatus = "expired";
      modified = true;
    }
  });
  if (modified) saveStore(systemStore);
  const totalClients = systemStore.users.length;
  const activeSubscriptions = systemStore.users.filter((u) => u.subscriptionStatus === "active" && u.subscriptionExpiresAt > now).length;
  const pendingActivation = systemStore.users.filter((u) => u.subscriptionStatus === "pending").length;
  const expiredOrFrozen = systemStore.users.filter((u) => u.subscriptionStatus === "expired" || u.subscriptionStatus === "frozen").length;
  res.json({
    success: true,
    serverTime: now,
    stats: {
      totalClients,
      activeSubscriptions,
      pendingActivation,
      expiredOrFrozen
    },
    clients: systemStore.users.map((u) => {
      const remainingDays = u.subscriptionExpiresAt > now ? Math.ceil((u.subscriptionExpiresAt - now) / 864e5) : 0;
      const remainingMs = Math.max(0, u.subscriptionExpiresAt - now);
      return {
        ...u,
        hasActiveLicense: u.subscriptionStatus === "active" && u.subscriptionExpiresAt > now,
        licenseRemainingMs: remainingMs,
        remainingDays
      };
    })
  });
});
app.post("/api/admin/merchants/activate", (req, res) => {
  const { phone, days, notes } = req.body;
  if (!phone) {
    return res.status(400).json({ success: false, message: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0627\u0644\u062A\u0627\u062C\u0631 \u0645\u0637\u0644\u0648\u0628" });
  }
  const cleanPhone = String(phone).trim();
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0646\u0638\u0627\u0645." });
  }
  const count = Math.max(1, parseInt(days, 10) || 30);
  const now = Date.now();
  const expiresAt = now + count * 864e5;
  user.subscriptionStatus = "active";
  user.subscriptionDays = count;
  user.subscriptionActivatedAt = now;
  user.subscriptionExpiresAt = expiresAt;
  if (notes !== void 0) user.notes = notes;
  saveStore(systemStore);
  console.log(`[\u062A\u0641\u0639\u064A\u0644 \u0645\u0628\u0627\u0634\u0631] \u062A\u0645 \u062A\u0641\u0639\u064A\u0644 \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u062A\u0627\u062C\u0631 ${user.fullName} (${user.shopName}) \u0644\u0645\u062F\u0629 ${count} \u064A\u0648\u0645\u0627\u064B \u062D\u062A\u0649: ${new Date(expiresAt).toLocaleString()}`);
  res.json({
    success: true,
    message: `\u062A\u0645 \u062A\u0641\u0639\u064A\u0644 \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u062A\u0627\u062C\u0631 (${user.fullName}) \u0628\u0646\u062C\u0627\u062D \u0644\u0645\u062F\u0629 ${count} \u064A\u0648\u0645\u0627\u064B!`,
    user: {
      ...user,
      remainingDays: count,
      remainingMs: count * 864e5
    }
  });
});
app.post("/api/admin/merchants/extend", (req, res) => {
  const { phone, extraDays, notes } = req.body;
  if (!phone) {
    return res.status(400).json({ success: false, message: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0627\u0644\u062A\u0627\u062C\u0631 \u0645\u0637\u0644\u0648\u0628" });
  }
  const cleanPhone = String(phone).trim();
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0646\u0638\u0627\u0645." });
  }
  const addedDays = Math.max(1, parseInt(extraDays, 10) || 30);
  const addedMs = addedDays * 864e5;
  const now = Date.now();
  if (user.subscriptionExpiresAt > now && user.subscriptionStatus === "active") {
    user.subscriptionExpiresAt += addedMs;
  } else {
    user.subscriptionExpiresAt = now + addedMs;
  }
  user.subscriptionStatus = "active";
  user.subscriptionDays += addedDays;
  if (notes !== void 0) user.notes = notes;
  saveStore(systemStore);
  const remainingDays = Math.ceil((user.subscriptionExpiresAt - now) / 864e5);
  res.json({
    success: true,
    message: `\u062A\u0645 \u062A\u0645\u062F\u064A\u062F \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u062A\u0627\u062C\u0631 (${user.fullName}) \u0628\u0625\u0636\u0627\u0641\u0629 ${addedDays} \u064A\u0648\u0645\u0627\u064B. \u0627\u0644\u0645\u062A\u0628\u0642\u064A \u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A: ${remainingDays} \u064A\u0648\u0645\u0627\u064B.`,
    user: {
      ...user,
      remainingDays
    }
  });
});
app.post("/api/admin/merchants/freeze", (req, res) => {
  const { phone } = req.body;
  const cleanPhone = String(phone).trim();
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  }
  user.subscriptionStatus = "frozen";
  saveStore(systemStore);
  res.json({
    success: true,
    message: `\u062A\u0645 \u062A\u062C\u0645\u064A\u062F \u0648\u0625\u064A\u0642\u0627\u0641 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u0627\u062C\u0631 (${user.fullName}) \u0628\u0646\u062C\u0627\u062D. \u0633\u064A\u062A\u0645 \u0642\u0641\u0644 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C \u0644\u062F\u064A\u0647 \u0641\u0648\u0631\u0627\u064B.`
  });
});
app.post("/api/admin/merchants/unfreeze", (req, res) => {
  const { phone } = req.body;
  const cleanPhone = String(phone).trim();
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  }
  const now = Date.now();
  if (user.subscriptionExpiresAt > now) {
    user.subscriptionStatus = "active";
  } else {
    user.subscriptionStatus = "expired";
  }
  saveStore(systemStore);
  res.json({
    success: true,
    message: `\u062A\u0645 \u0641\u0643 \u0627\u0644\u062A\u062C\u0645\u064A\u062F \u0639\u0646 \u062D\u0633\u0627\u0628 \u0627\u0644\u062A\u0627\u062C\u0631 (${user.fullName}). \u0627\u0644\u062D\u0627\u0644\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629: ${user.subscriptionStatus === "active" ? "\u0646\u0634\u0637" : "\u0645\u0646\u062A\u0647\u064A"}.`
  });
});
app.post("/api/admin/users/delete", (req, res) => {
  const { id, phone } = req.body;
  const initialCount = systemStore.users.length;
  systemStore.users = systemStore.users.filter((u) => u.id !== id && u.phone !== phone);
  if (systemStore.users.length === initialCount) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u062D\u0630\u0641\u0647 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  }
  saveStore(systemStore);
  console.log(`[\u062D\u0630\u0641 \u062A\u0627\u062C\u0631] \u062A\u0645 \u062D\u0630\u0641 \u0627\u0644\u062A\u0627\u062C\u0631 ${phone} \u0646\u0647\u0627\u0626\u064A\u0627\u064B \u0645\u0646 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A.`);
  res.json({
    success: true,
    message: "\u062A\u0645 \u062D\u0630\u0641 \u062D\u0633\u0627\u0628 \u0648\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u0627\u062C\u0631 \u0646\u0647\u0627\u0626\u064A\u0627\u064B \u0645\u0646 \u0627\u0644\u0646\u0638\u0627\u0645."
  });
});
app.post("/api/admin/merchants/update-password", (req, res) => {
  const { phone, newPassword } = req.body;
  if (!phone || !newPassword) {
    return res.status(400).json({ success: false, message: "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062A\u0641 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0645\u0637\u0644\u0648\u0628\u0627\u0646." });
  }
  const cleanPhone = String(phone).trim();
  const user = systemStore.users.find((u) => u.phone === cleanPhone);
  if (!user) {
    return res.status(404).json({ success: false, message: "\u0627\u0644\u062A\u0627\u062C\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0627\u0644\u0646\u0638\u0627\u0645." });
  }
  user.password = String(newPassword).trim();
  user.updatedAt = Date.now();
  saveStore(systemStore);
  console.log(`[\u062A\u062D\u062F\u064A\u062B \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631] \u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0644\u0644\u062A\u0627\u062C\u0631 ${user.fullName} (${user.phone}) \u0628\u0646\u062C\u0627\u062D.`);
  res.json({
    success: true,
    message: `\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0644\u0644\u062A\u0627\u062C\u0631 (${user.fullName}) \u0628\u0646\u062C\u0627\u062D.`
  });
});
app.get("/api/native/projects", (req, res) => {
  const androidPath = import_path.default.join(process.cwd(), "native-src", "android");
  const windowsPath = import_path.default.join(process.cwd(), "native-src", "windows");
  res.json({
    success: true,
    android: {
      framework: "Kotlin Native / Jetpack Compose",
      target: "Android 8.0 to Android 14+ (APK & AAB)",
      database: "Room SQLite Database (100% Offline)",
      security: "EncryptedSharedPreferences (AES-256-GCM) + Hardware Android ID Binding",
      buildInstructions: [
        "\u0627\u0641\u062A\u062D \u0645\u062C\u0644\u062F native-src/android \u0641\u064A \u0628\u0631\u0646\u0627\u0645\u062C Android Studio",
        "\u0627\u0636\u063A\u0637 \u0639\u0644\u0649 Build > Build APKs \u0623\u0648 \u0646\u0641\u0630 \u0627\u0644\u0623\u0645\u0631: ./gradlew assembleRelease",
        "\u0633\u062A\u062C\u062F \u0645\u0644\u0641 APK \u0627\u0644\u062D\u0642\u064A\u0642\u064A \u0641\u064A: app/build/outputs/apk/release/Idenia-Hisba.apk"
      ]
    },
    windows: {
      framework: "C# / .NET 8 WPF",
      target: "Windows 10 / 11 64-bit (Standalone .exe)",
      database: "Microsoft.Data.Sqlite (100% Offline)",
      security: "Windows DPAPI + Motherboard UUID & CPU ID Serial Locking",
      buildInstructions: [
        "\u062A\u0623\u0643\u062F \u0645\u0646 \u062A\u062B\u0628\u064A\u062A .NET 8 SDK \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0643",
        "\u0646\u0641\u0630 \u0627\u0644\u0623\u0645\u0631: dotnet publish -c Release -r win-x64 --self-contained -p:PublishSingleFile=true -o ./dist",
        "\u0633\u062A\u062C\u062F \u0645\u0644\u0641 Idenia-Hisba.exe \u0627\u0644\u0645\u0633\u062A\u0642\u0644 \u0628\u0630\u0627\u062A\u0647 \u062C\u0627\u0647\u0632\u0627\u064B \u0644\u0644\u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0641\u0648\u0631\u064A \u0648\u0627\u0644\u062A\u0648\u0632\u064A\u0639"
      ]
    }
  });
});
app.get("/api/native/download/:platform?", async (req, res) => {
  try {
    const platform = req.params.platform;
    const archive = new ZipArchive2({ zlib: { level: 9 } });
    const filename = platform === "windows" ? "idenia-windows-csharp-source.zip" : platform === "android" ? "idenia-android-kotlin-source.zip" : "idenia-complete-native-sources.zip";
    const chunks = [];
    archive.on("data", (chunk) => chunks.push(chunk));
    const zipPromise = new Promise((resolve, reject) => {
      archive.on("end", () => resolve(Buffer.concat(chunks)));
      archive.on("error", (err) => reject(err));
    });
    if (platform === "windows") {
      const dir = import_path.default.join(process.cwd(), "native-src", "windows");
      if (import_fs.default.existsSync(dir)) {
        archive.directory(dir, false);
      }
    } else if (platform === "android") {
      const dir = import_path.default.join(process.cwd(), "native-src", "android");
      if (import_fs.default.existsSync(dir)) {
        archive.directory(dir, false);
      }
    } else {
      const dir = import_path.default.join(process.cwd(), "native-src");
      if (import_fs.default.existsSync(dir)) {
        archive.directory(dir, false);
      }
    }
    archive.finalize();
    const zipBuffer = await zipPromise;
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Length", zipBuffer.length.toString());
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.end(zipBuffer);
  } catch (err) {
    console.error("[Download Native Source Error]:", err);
    if (!res.headersSent) {
      res.status(500).json({ success: false, message: "\u0641\u0634\u0644 \u062A\u0648\u0644\u064A\u062F \u0645\u0644\u0641 \u0627\u0644\u062D\u0632\u0645\u0629 \u0627\u0644\u0645\u0636\u063A\u0648\u0637\u0629" });
    }
  }
});
app.get("/api/flutter/download", async (req, res) => {
  try {
    const archive = new ZipArchive2({ zlib: { level: 9 } });
    const filename = "idenia-hisba-flutter-android-windows.zip";
    const chunks = [];
    archive.on("data", (chunk) => chunks.push(chunk));
    const zipPromise = new Promise((resolve, reject) => {
      archive.on("end", () => resolve(Buffer.concat(chunks)));
      archive.on("error", (err) => reject(err));
    });
    const flutterDir = import_path.default.join(process.cwd(), "flutter_idenia_hisba");
    if (import_fs.default.existsSync(flutterDir)) {
      archive.directory(flutterDir, false);
    }
    archive.finalize();
    const zipBuffer = await zipPromise;
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Length", zipBuffer.length.toString());
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.end(zipBuffer);
  } catch (err) {
    console.error("[Download Flutter Source Error]:", err);
    if (!res.headersSent) {
      res.status(500).json({ success: false, message: "\u0641\u0634\u0644 \u062A\u0648\u0644\u064A\u062F \u0645\u0644\u0641 \u062D\u0632\u0645\u0629 \u0641\u0644\u0627\u062A\u0631" });
    }
  }
});
app.post("/api/admin/rebuild-installers", (req, res) => {
  const scriptPath = import_path.default.join(process.cwd(), "scripts", "rebuild_all_installers.py");
  if (!import_fs.default.existsSync(scriptPath)) {
    return res.status(404).json({ success: false, message: "\u0633\u0643\u0631\u0628\u062A \u0627\u0644\u0628\u0646\u0627\u0621 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  }
  const { spawn } = require("child_process");
  const proc = spawn("python3", [scriptPath], { cwd: process.cwd() });
  let output = "";
  let errorOutput = "";
  proc.stdout.on("data", (data) => {
    output += data.toString();
  });
  proc.stderr.on("data", (data) => {
    errorOutput += data.toString();
  });
  proc.on("close", (code) => {
    if (code === 0) {
      res.json({
        success: true,
        message: "\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u0628\u0646\u0627\u0621 \u062D\u0632\u0645 \u0627\u0644\u062A\u062B\u0628\u064A\u062A \u0644\u0644\u0623\u0646\u062F\u0631\u0648\u064A\u062F \u0648\u0627\u0644\u0648\u064A\u0646\u062F\u0648\u0632 \u0628\u0623\u062D\u062F\u062B \u0643\u0648\u062F \u0628\u0646\u062C\u0627\u062D!",
        output
      });
    } else {
      console.error("[Rebuild Installers Error]:", errorOutput);
      res.status(500).json({
        success: false,
        message: "\u0641\u0634\u0644 \u0623\u062B\u0646\u0627\u0621 \u062A\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0632\u0645: " + (errorOutput || output),
        code
      });
    }
  });
});
app.get("/api/admin/packages-status", (req, res) => {
  const downloadsDir = import_path.default.join(process.cwd(), "downloads");
  const files = [
    { name: "idenia-hisba.apk", label: "\u062A\u0637\u0628\u064A\u0642 \u0623\u0646\u062F\u0631\u0648\u064A\u062F \u0627\u0644\u0645\u0633\u062A\u0642\u0644 (100% Offline APK)" },
    { name: "IdeniaHisba_Setup.exe", label: "\u0645\u062B\u0628\u062A \u0648\u064A\u0646\u062F\u0648\u0632 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 (Setup.exe)" },
    { name: "idenia-hisba-windows-setup.zip", label: "\u062D\u0632\u0645\u0629 \u0648\u064A\u0646\u062F\u0648\u0632 \u0627\u0644\u0645\u0636\u063A\u0648\u0637\u0629 (ZIP Package)" },
    { name: "MicrosoftEdgeWebview2Setup.exe", label: "\u0645\u062B\u0628\u062A WebView2 \u0644\u0648\u064A\u0646\u062F\u0648\u0632" }
  ];
  const status = files.map((f) => {
    const p = import_path.default.join(downloadsDir, f.name);
    const exists = import_fs.default.existsSync(p);
    let size = 0;
    let modifiedAt = null;
    if (exists) {
      const st = import_fs.default.statSync(p);
      size = st.size;
      modifiedAt = st.mtime.toISOString();
    }
    return {
      ...f,
      exists,
      size,
      sizeFormatted: exists ? (size / (1024 * 1024)).toFixed(2) + " MB" : "\u063A\u064A\u0631 \u0645\u062A\u0648\u0641\u0631",
      modifiedAt
    };
  });
  res.json({ success: true, packages: status });
});
function getDownloadFilePath(fileName) {
  const possiblePaths = [
    import_path.default.join(process.cwd(), "downloads", fileName),
    import_path.default.join(process.cwd(), "public", fileName),
    import_path.default.join(process.cwd(), "dist", fileName)
  ];
  for (const p of possiblePaths) {
    if (import_fs.default.existsSync(p)) return p;
  }
  return null;
}
app.get(["/api/download/android-apk", "/downloads/idenia-hisba.apk", "/idenia-hisba.apk"], (req, res) => {
  const apkPath = getDownloadFilePath("idenia-hisba.apk");
  if (!apkPath) {
    return res.status(404).json({ success: false, message: "\u0645\u0644\u0641 APK \u0642\u064A\u062F \u0627\u0644\u062A\u062C\u0647\u064A\u0632\u060C \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0628\u0639\u062F \u0644\u062D\u0638\u0627\u062A." });
  }
  res.setHeader("Content-Type", "application/vnd.android.package-archive");
  res.setHeader("Content-Disposition", 'attachment; filename="idenia-hisba.apk"');
  res.setHeader("Cache-Control", "no-cache");
  import_fs.default.createReadStream(apkPath).pipe(res);
});
app.get(["/api/download/windows-setup", "/downloads/idenia-hisba-windows-setup.zip", "/idenia-hisba-windows-setup.zip"], (req, res) => {
  const zipPath = getDownloadFilePath("idenia-hisba-windows-setup.zip");
  if (!zipPath) {
    return res.status(404).json({ success: false, message: "\u0645\u0644\u0641 \u0627\u0644\u062A\u062B\u0628\u064A\u062A \u0644\u0648\u064A\u0646\u062F\u0648\u0632 \u0642\u064A\u062F \u0627\u0644\u062A\u062C\u0647\u064A\u0632\u060C \u064A\u0631\u062C\u0649 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0628\u0639\u062F \u0644\u062D\u0638\u0627\u062A." });
  }
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", 'attachment; filename="idenia-hisba-windows-setup.zip"');
  res.setHeader("Cache-Control", "no-cache");
  import_fs.default.createReadStream(zipPath).pipe(res);
});
app.get(["/api/download/windows-exe", "/downloads/IdeniaHisba_Setup.exe", "/IdeniaHisba_Setup.exe"], (req, res) => {
  const exePath = getDownloadFilePath("IdeniaHisba_Setup.exe");
  if (!exePath) {
    return res.status(404).json({ success: false, message: "\u0645\u0644\u0641 Setup.exe \u0642\u064A\u062F \u0627\u0644\u062A\u062C\u0647\u064A\u0632." });
  }
  res.setHeader("Content-Type", "application/vnd.microsoft.portable-executable");
  res.setHeader("Content-Disposition", 'attachment; filename="IdeniaHisba_Setup.exe"');
  res.setHeader("Cache-Control", "no-cache");
  import_fs.default.createReadStream(exePath).pipe(res);
});
app.get(["/api/download/webview2-setup", "/MicrosoftEdgeWebview2Setup.exe"], (req, res) => {
  const wv2Path = getDownloadFilePath("MicrosoftEdgeWebview2Setup.exe");
  if (!wv2Path) {
    return res.status(404).json({ success: false, message: "\u0645\u0644\u0641 WebView2 Setup \u0642\u064A\u062F \u0627\u0644\u062A\u062C\u0647\u064A\u0632." });
  }
  res.setHeader("Content-Type", "application/vnd.microsoft.portable-executable");
  res.setHeader("Content-Disposition", 'attachment; filename="MicrosoftEdgeWebview2Setup.exe"');
  res.setHeader("Cache-Control", "no-cache");
  import_fs.default.createReadStream(wv2Path).pipe(res);
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[\u0627\u064A\u062F\u064A\u0646\u064A\u0627 - \u062D\u0650\u0633\u0628\u0629] \u0627\u0644\u062E\u0627\u062F\u0645 \u064A\u0639\u0645\u0644 \u0628\u0646\u062C\u0627\u062D \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u0641\u0630: http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Fatal error starting server:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
